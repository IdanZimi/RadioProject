A Pen created at CodePen.io. You can find this one at http://codepen.io/fredjens/pen/adqLNO.

 Animated switch build with radio buttons.